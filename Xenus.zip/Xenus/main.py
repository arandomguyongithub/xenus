#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading, sys, os, io, re, subprocess
import google.generativeai as genai

# ======= CONFIGURATION =======
API_KEY = "AIzaSyConO5CWGTzMdrb82lculNwbGYt6EMOD8g"  # <-- your key locally
MODEL_NAME = "gemini-2.5-flash"
EXEC_MODE = "subprocess"  # choose "subprocess" or "exec"
# =============================

# silence grpc warnings before importing
os.environ.setdefault("GRPC_VERBOSITY", "ERROR")
os.environ.setdefault("GRPC_LOG_SEVERITY_LEVEL", "ERROR")

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel(MODEL_NAME)
chat = model.start_chat(history=[])

# custom instructions
chat.send_message(
    "You are an assistant named Xenus. When you include code inside triple backticks, "
    "the user program will automatically execute it. Use ```python``` fences when possible. "
    "Always use os.system() when executing code (to run bash commands). "
    "The user is on macOS. Be concise and helpful."
)

CODE_BLOCK_RE = re.compile(r"```(?:python)?\n(.*?)```", re.DOTALL | re.IGNORECASE)

# --- execution functions ---
def run_code_subprocess(code: str, timeout: int = 10):
    try:
        proc = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.stdout, proc.stderr
    except subprocess.TimeoutExpired:
        return "", "Error: execution timed out.\n"

def run_code_exec(code: str):
    buffer, err_buffer = io.StringIO(), io.StringIO()
    safe_builtins = {
        "print": print, "len": len, "range": range,
        "int": int, "float": float, "str": str,
        "list": list, "dict": dict, "set": set, "tuple": tuple,
        "os": os,
    }
    globals_dict = {"__builtins__": safe_builtins}
    try:
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = buffer, err_buffer
        exec(code, globals_dict)
    except Exception as e:
        err_buffer.write(f"Error: {e}\n")
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr
    return buffer.getvalue(), err_buffer.getvalue()

def execute_code_block(code, textbox):
    textbox.configure(state="normal")
    textbox.insert(tk.END, "\n⚙️  Xenus executing code block...\n", "system")
    textbox.configure(state="disabled")
    textbox.see(tk.END)

    if EXEC_MODE == "subprocess":
        stdout, stderr = run_code_subprocess(code)
    else:
        stdout, stderr = run_code_exec(code)

    textbox.configure(state="normal")
    if stdout:
        textbox.insert(tk.END, stdout, "stdout")
    if stderr:
        textbox.insert(tk.END, stderr, "stderr")
    if not stdout and not stderr:
        textbox.insert(tk.END, "[No output]\n", "system")
    textbox.configure(state="disabled")
    textbox.see(tk.END)

# --- ui ---
class XenusApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Xenus")
        self.root.geometry("840x640")
        self.root.configure(bg="#1e1e1e")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TEntry", fieldbackground="#2b2b2b", foreground="white")
        style.configure("TButton", background="#3c3c3c", foreground="white")

        self.chat_display = scrolledtext.ScrolledText(
            root, wrap=tk.WORD, state="disabled",
            bg="#1e1e1e", fg="#ffffff",
            insertbackground="white", font=("Consolas", 11),
        )
        self.chat_display.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.chat_display.tag_config("user", foreground="#ffcc66")
        self.chat_display.tag_config("bot", foreground="#66d9ef")
        self.chat_display.tag_config("stdout", foreground="#a6e22e")
        self.chat_display.tag_config("stderr", foreground="#f92672")
        self.chat_display.tag_config("system", foreground="#999999", font=("Consolas", 10, "italic"))

        input_frame = tk.Frame(root, bg="#252526")
        input_frame.pack(fill=tk.X, padx=10, pady=5)

        self.entry = ttk.Entry(input_frame, font=("Consolas", 12))
        self.entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        self.entry.bind("<Return>", self.on_send)

        send_button = ttk.Button(input_frame, text="Send", command=self.on_send)
        send_button.pack(side=tk.RIGHT)

        self.add_message("Xenus", "💫 Welcome to Xenus! Type something below.\n")

    def add_message(self, sender, text):
        tag = "user" if sender == "You" else "bot"
        self.chat_display.configure(state="normal")
        self.chat_display.insert(tk.END, f"{sender}: ", tag)
        self.chat_display.insert(tk.END, text + "\n")
        self.chat_display.configure(state="disabled")
        self.chat_display.see(tk.END)

    def on_send(self, event=None):
        msg = self.entry.get().strip()
        if not msg:
            return
        self.add_message("You", msg)
        self.entry.delete(0, tk.END)
        threading.Thread(target=self.handle_chat, args=(msg,)).start()

    def handle_chat(self, msg):
        try:
            response = chat.send_message(msg)
            text = (response.text or "").strip()
            code_blocks = CODE_BLOCK_RE.findall(text)
            cleaned_text = CODE_BLOCK_RE.sub("", text).strip()

            if cleaned_text:
                self.add_message("Xenus", cleaned_text)

            for code in code_blocks:
                execute_code_block(code, self.chat_display)

        except Exception as e:
            messagebox.showerror("Error", f"Something went wrong:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    root.iconphoto(False, tk.PhotoImage(file=os.path.expanduser("~/Xenus/xenus.png")))
    XenusApp(root)
    root.mainloop()
